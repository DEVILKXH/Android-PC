package com.fzu.useBean;

/**
 * Created by Devil on 2016/5/16.
 */
public class ProrassBar {
    private static long length;

    public static long getLength() {
        return length;
    }
    public static void setLength(long length) {
        ProrassBar.length = length;
    }
}
